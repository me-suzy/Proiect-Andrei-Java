/*
 * Disciplina.java
 *
 * Created on April 3, 2004, 10:44 PM
 */

package gestnote;

/**
 *
 * @author  Cezar
 */
public class Disciplina {
    public String denumire;
    public int nrCredite;
    
    /** Creates a new instance of Disciplina */
    public Disciplina(String nume, int credite) {
        this.denumire=nume;
        this.nrCredite=credite;
    }
    
}
