/*
 * AbstractNota.java
 *
 * Created on April 3, 2004, 11:19 PM
 */

package gestnote;

/**
 *
 * @author  Cezar
 */
public abstract class AbstractNota {
    public AbstractNota(){}
    public abstract double getNotaFin();      
}
