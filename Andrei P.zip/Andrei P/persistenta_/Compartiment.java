/*
 * Compartiment.java
 *
 * Created on April 30, 2004, 11:39 AM
 */

package persistenta;

/**
 *
 * @author  el010741
 */
public class Compartiment {
    
    /** Creates a new instance of Compartiment */
    public Compartiment() {
    }
    
}
