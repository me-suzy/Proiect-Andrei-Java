/*
 * Java1.java
 *
 * Created on March 2, 2004, 10:01 AM
 */

/**
 *
 * @author  panzariu andrei
 */
public class Java1 {
    
    /** Creates a new instance of Java1 */
    public Java1() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
